import UserAuthentication from "./UserAuthentication";

export default class SimpleUserAuthentication extends UserAuthentication {

  private userName: string;
  private password: string;

  constructor(userName: string, password: string, clientTypeHeader: string) {
    super(clientTypeHeader);
    this.userName = userName;
    this.password = password;
  }

  getUserName(): string {
    return this.userName;
  }

  getPassword(): string {
    return this.password;
  }
}
