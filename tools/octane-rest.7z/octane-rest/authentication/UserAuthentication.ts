import IAuthentication from "./IAuthentication";

export default abstract class UserAuthentication implements IAuthentication {
  private clientTypeHeader: string;

  constructor(clientTypeHeader: string) {
    this.clientTypeHeader = clientTypeHeader;
  }

  getClientHeader(): string {
    return this.clientTypeHeader;
  }

  getAuthenticationJsonObj(): any {
    return {user: this.getUserName(), password: this.getPassword()};
  }

  abstract getUserName(): string;

  abstract getPassword(): string  ;
}
