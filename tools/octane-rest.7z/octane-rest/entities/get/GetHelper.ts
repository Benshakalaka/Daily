/**
 * A helper for getting entities
 */
import {OctaneRequest} from "../../network/OctaneRequest";
import {EntityModel} from "../../model/EntityModel";
import {GetOctaneHttpRequest, OctaneHttpRequest} from "../../network/OctaneHttpRequest";
import {IPromise} from "angular";
import {OctaneCollection} from "../OctaneCollection";

export class GetHelper {

  private static INSTANCE: GetHelper = new GetHelper();

  private constructor() {
  }

  static getInstance(): GetHelper {
    return GetHelper.INSTANCE;
  }

  /**
   * 1. Request GetEntities Execution
   * 2. Parse response to a new Collection object
   */
  getEntityModels(octaneRequest: OctaneRequest): IPromise<OctaneCollection<EntityModel>> {
    let octaneHttpRequest: OctaneHttpRequest = new GetOctaneHttpRequest(octaneRequest.getFinalRequestUrl()).setAcceptType(OctaneHttpRequest.JSON_CONTENT_TYPE);
    return octaneRequest.getEntitiesResponse(octaneHttpRequest);
  }

  /**
   * 1. GetEntities Request execution with json data 2. Parse response to a
   * new EntityModel object
   */
  getEntityModel(octaneRequest: OctaneRequest): IPromise<EntityModel> {
    let octaneHttpRequest: OctaneHttpRequest =
      new GetOctaneHttpRequest(octaneRequest.getFinalRequestUrl())
        .setAcceptType(OctaneHttpRequest.JSON_CONTENT_TYPE);
    return octaneRequest.getEntityResponse(octaneHttpRequest);
  }

}
