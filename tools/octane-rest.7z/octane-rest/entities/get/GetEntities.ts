/**
 * This class hold the GetEntities objects and serve all functions concern to REST
 * GetEntities.
 */
import OctaneHttpClient from "../../network/OctaneHttpClient";
import {IPromise} from "angular";
import {Query} from "../../query/Query";
import {OctaneRequest} from "../../network/OctaneRequest";
import {EntityModel} from "../../model/EntityModel";
import {GetHelper} from "./GetHelper";
import {OctaneCollection} from "../OctaneCollection";

export class GetEntities {

  protected octaneRequest: OctaneRequest;

  public constructor(octaneHttpClient: OctaneHttpClient, urlDomain: string) {
    this.octaneRequest = new OctaneRequest(octaneHttpClient, urlDomain);
  }

  /**
   * 1. Request GetEntities Execution <br>
   * 2. Parse response to a new Collection object
   * @return a collection of entities models that have been retrieved
   */
  public execute(): IPromise<OctaneCollection<EntityModel>> {
    return GetHelper.getInstance().getEntityModels(this.octaneRequest);
  }

  /**
   * Add Fields parameters
   *
   * @param fields An array of fields that will be part of the HTTP Request
   * @return GetEntities Object with new Fields parameters
   */
  public addFields(fields: string[]): GetEntities {
    this.octaneRequest.getOctaneUrl().addFieldsParam(fields);
    return this;
  }

  /**
   * Add Limit parameter
   *
   * @param limit The entity limit
   * @return GetEntities Object with new limit parameter
   */
  public limit(limit: string): GetEntities {
    this.octaneRequest.getOctaneUrl().setLimitParam(limit);
    return this;
  }

  /**
   * Add offset parameter
   *
   * @param offset The entity limit offset
   * @return GetEntities Object with new offset parameter
   */
  public offset(offset: string): GetEntities {
    this.octaneRequest.getOctaneUrl().setOffsetParam(offset);
    return this;
  }

  /**
   * Add OrderBy parameters
   *
   * @param orderBy The string which determines how the entities should be ordered
   * @param asc     - true=ascending/false=descending
   * @return GetEntities Object with new OrderBy parameters
   */
  public addOrderBy(orderBy: string, asc: boolean): GetEntities {
    this.octaneRequest.getOctaneUrl().setOrderByParam(orderBy, asc);
    return this;
  }

  /**
   * @param query The query to use
   * @return The object
   */
  public query(query: Query): GetEntities {
    this.octaneRequest.getOctaneUrl().setDqlQueryParam(query);
    return this;
  }
}
