/**
 * A helper for creating entities
 */
import {EntityModel} from "../../model/EntityModel";
import {OctaneRequest} from "../../network/OctaneRequest";
import {IPromise} from "angular";
import {OctaneHttpRequest, PostOctaneHttpRequest} from "../../network/OctaneHttpRequest";
import {OctaneCollection} from "../OctaneCollection";

export class CreateHelper {

  private static INSTANCE: CreateHelper = new CreateHelper();

  private constructor() {
  }

  static getInstance(): CreateHelper {
    return CreateHelper.INSTANCE;
  }

  /**
   * 1. build Entity Json Object  2. Post
   * Request execution with json data 3. Parse response to a new
   * object
   * @param entityModels the collection of entitymodels
   * @param octaneRequest the octane request
   */
  createEntities(entityModels: Array<EntityModel>, octaneRequest: OctaneRequest): IPromise<OctaneCollection<EntityModel>> {

    let newEntityModels = Array<EntityModel>();
    // TODO: implement coversion from entities to json strings
    // JSONObject objBase = ModelParser.getInstance().getEntitiesJSONObject(entityModels);
    // String strJsonEntityModel = objBase.toString();

    let strJsonEntityModel = '';

    let octaneHttpRequest: OctaneHttpRequest =
      new PostOctaneHttpRequest(octaneRequest.getFinalRequestUrl(), OctaneHttpRequest.JSON_CONTENT_TYPE, strJsonEntityModel)
        .setAcceptType(OctaneHttpRequest.JSON_CONTENT_TYPE);

    return octaneRequest.getEntitiesResponse(octaneHttpRequest);

    //TODO: partial support
  }
}
