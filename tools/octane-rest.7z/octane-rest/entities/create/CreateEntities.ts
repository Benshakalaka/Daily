/**
 * This class hold the CreateEntities objects and serve all functions concern to
 * REST Post.
 */
import OctaneHttpClient from "../../network/OctaneHttpClient";
import {EntityModel} from "../../model/EntityModel";
import {OctaneRequest} from "../../network/OctaneRequest";
import {CreateHelper} from "./CreateHelper";
import {IPromise} from "angular";
import {OctaneCollection} from "../OctaneCollection";

export class CreateEntities {

  private entityModels: EntityModel[] = null;
  private octaneRequest: OctaneRequest;

  public constructor(octaneHttpClient: OctaneHttpClient, urlDomain: string) {
    this.octaneRequest = new OctaneRequest(octaneHttpClient, urlDomain);
  }

  /**
   * 1. build Entity Json Object  2. Post
   * Request execution with json data 3. Parse response to a new
   * object
   * @return a collection of entities models that have been created
   */
  public execute(): IPromise<OctaneCollection<EntityModel>> {
    return CreateHelper.getInstance().createEntities(this.entityModels, this.octaneRequest);
  }

  /**
   * Set new entities collection
   *
   * @param entities The entities which will be created
   * @return create Object with new entities collection
   */
  public entities(entities: Array<EntityModel>): CreateEntities {

    this.entityModels = entities;
    return this;
  }
}
