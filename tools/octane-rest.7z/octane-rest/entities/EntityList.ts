/**
 * This class represents the entity context and carries out the actual server requests.  It builds the correct URL as
 * appropriate
 *
 */
import OctaneHttpClient from "../network/OctaneHttpClient";
import {GetEntities} from "./get/GetEntities";

export class EntityList {
  // **** public Functions ***

  /**
   * Creates a new EntityList object.  This represents an entity collection
   *
   * @param octaneHttpClient - Http Client
   * @param entityListDomain - Domain Name
   */
  public constructor(protected octaneHttpClient: OctaneHttpClient, protected urlDomain: string) {

  }

  /**
   * getter of an Entities object ( Entities object handle a unique entity
   * model )
   *
   * @param entityId - entity id
   * @return a new Entities object with specific id
   */
  public at(entityId: string): Entities {
    return new Entities(entityId);
  }

  /**
   * getter of an GetEntities object of EntityList ( EntityList object handle a
   * collection of entity models )
   *
   * @return a new GetEntities object
   */
  public get(): GetEntities {
    return new GetEntities(this.octaneHttpClient, this.urlDomain);
  }

  // /**
  //  * getter of an UpdateEntities object of EntityList ( EntityList object handle a
  //  * collection of entity models )
  //  *
  //  * @return a new UpdateEntities object
  //  */
  // public update(): UpdateEntities {
  //   return new UpdateEntities(this.octaneHttpClient, this.urlDomain);
  // }
  //
  // /**
  //  * getter of an CreateEntities object of EntityList ( EntityList object handle a
  //  * collection of entity models
  //  *
  //  * @return a new CreateEntities object
  //  */
  // public create(): CreateEntities {
  //   return new CreateEntities(this.octaneHttpClient, this.urlDomain);
  // }
  //
  // /**
  //  * getter of an DeleteEntities object of EntityList ( EntityList object handle a
  //  * collection of entity models
  //  *
  //  * @return a new DeleteEntities object
  //  */
  // public delete(): DeleteEntities {
  //   return new DeleteEntities(this.octaneHttpClient, this.urlDomain);
  // }
}


// **** Classes ***

/**
 * This class hold the Entities object(An object that represent one Entity )
 */
export class Entities {

  /**
   * Set entityId parameter
   *
   * @param entityId The entity id
   */
  constructor(private entityId: string) {
    this.entityId = entityId;
  }

  // /**
  //  * getter of a GetEntities object with specific entity
  //  *
  //  * @return The GetEntities object
  //  */
  // public get(): GetEntity {
  //   return new GetEntity(octaneHttpClient, urlDomain, entityId);
  // }
  //
  // /**
  //  * getter of a UpdateEntities object with specific entity
  //  *
  //  * @return The UpdateEntities object
  //  */
  // public update(): UpdateEntity {
  //   return new UpdateEntity(octaneHttpClient, urlDomain, entityId);
  // }
  //
  // /**
  //  * getter of a CreateEntities object with specific entity
  //  *
  //  * @return The DeleteEntities object
  //  */
  // public delete(): DeleteEntity {
  //   return new DeleteEntity(octaneHttpClient, urlDomain, entityId);
  // }

}
