/**
 * An extension of the {@link Collection} interface that incorporates important metadata about the collection that has
 * been returned.
 *
 *  These are the total_count and exceeds_total_count fields.  These are important when scrolling through paged data to
 *  know whether there is more data to fetch.  Exceeds total count signifies whether the requested data page size is larger
 *  than allowed by server constraints.
 *
 *  See the REST API documentation for more details
 */
import {Entity} from "../model/Entity";

export interface OctaneCollection<T extends Entity> {

  /**
   * The total count of available entities that answer to the current query
   * @return total count or NO_TOTAL_COUNT_SET if not set
   */
  getTotalCount(): number;

  /**
   * Whether the requested number of entities exceeds the total available number of entities
   * @return exceeds total count (false if not set as well)
   */
  exceedsTotalCount(): boolean;

  getCollection(): Array<T>;

}
