/**
 * Utility class for building URLs for the implementation of the {@link OctaneHttpClient}
 */
import {Query} from "../query/Query";

interface IHashMap {
  [key: string]: string
}

export class OctaneUrl {
  public static LIMIT_PARAM_NAME = "limit";
  private static OFFSET_PARAM_NAME = "offset";
  private static FIELDS_PARAM_NAME = "fields";
  private static ORDER_BY_PARAM_NAME = "order_by";
  private static QUERY_PARAM_NAME = "query";

  private static PATH_SEPARATOR = "/";

  private baseUrl: string;
  private queryParams: IHashMap = {};
  private paths: Array<string> = new Array<string>();

  /**
   * Create a url starting from the provided base
   * @param baseUrl scheme:[//[user[:password]@]host[:port]]
   */
  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  /**
   * Add a path or more paths to the url, paths are concatenated into the final url
   * @param paths string or a list of strings representing the path from the base url
   */
  addPaths(paths: string) {
    let subPaths = paths.split(OctaneUrl.PATH_SEPARATOR);
    this.paths = this.paths.concat(subPaths);
  }

  /**
   * Return the current paths
   * @return list of strings representing the path of the current url
   */
  public getPaths(): string[] {
    return this.paths;
  }

  /**
   * Check whether the query param with {@code paramName} has already been set via {@link #setParam(String, String)}
   * @param paramName name of the parameter
   * @return true if the param was set, false otherwise
   */
  public hasParam(paramName: string): boolean {
    return !!this.queryParams[paramName];
  }

  /**
   * Set query param
   * @param paramName name of the parameter
   * @param paramValue value of the parameter
   */
  public setParam(paramName: string, paramValue: string) {
    this.queryParams[paramName] = paramValue;
  }

  /**
   * Get the value of the query param
   * @param paramName name of the parameter
   * @return value of the parameter
   */
  public getParam(paramName: string): string {
    return this.queryParams[paramName];
  }


  /**
   * Set hte value of the "fields" param,
   * @param fields list of fields of the Entity to be retrieved
   */
  public addFieldsParam(fields: Array<string>) {
    let fieldsString = fields.join(",");
    if (this.hasParam(OctaneUrl.FIELDS_PARAM_NAME)) {
      this.getParam(OctaneUrl.FIELDS_PARAM_NAME + "," + fieldsString);
    } else {
      this.setParam(OctaneUrl.FIELDS_PARAM_NAME, fieldsString);
    }
  }

  /**
   * Set query param named "limit", for the Octane API it controls max number of results returned from the data-set, <br>
   * can be used for pagination together with {@link #setOffsetParam(int)}
   * @param limit value of limit
   */
  public setLimitParam(limit: string) {
    this.setParam(OctaneUrl.LIMIT_PARAM_NAME, limit);
  }

  /**
   * Set query param named "offset", for the Octane API it controls the offset from the fist entity of the data-set, <br>
   * can be used for pagination together with {@link #setLimitParam(int)}
   * @param offset value of offset
   */
  public setOffsetParam(offset: string) {
    this.setParam(OctaneUrl.OFFSET_PARAM_NAME, offset);
  }

  /**
   * Set the value of the "order_by" param
   * @param orderBy name of a field of an {@link com.hpe.adm.nga.sdk.model.EntityModel}, to sort by
   * @param asc true for ascending, false for descending
   */
  public setOrderByParam(orderBy: string, asc: boolean) {
    let ascString = asc ? "" : "-";
    let orderByString = ascString + orderBy;
    this.setParam(OctaneUrl.ORDER_BY_PARAM_NAME, orderByString);
  }

  /**
   * Set a param named "query" that is used to filter data
   * @param query {@link Query} object, build by {@link com.hpe.adm.nga.sdk.query.Query.QueryBuilder}
   */
  public setDqlQueryParam(query: Query) {
    this.setParam(OctaneUrl.QUERY_PARAM_NAME, '"' + query.getQueryString() + '"');
  }

  /**
   * Concatenate the query params for the url builder
   * @return String of form: queryParamName1=queryParamValue1&queryParamName2=queryParamValue2
   */
  private createQueryString(): string {
    let pairs: string[] = [];
    for (let key in this.queryParams) {
      let tmp = key + '=' + this.queryParams[key];
      pairs.push(tmp);
    }
    return pairs.join('&');
  }

  /**
   * Build the url string from the state of this object
   * @return URL string containing base url with paths and query params
   */
  public toString(): string {
    let url = this.baseUrl;

    //Append paths
    if (this.getPaths().length > 0) {
      if (url.lastIndexOf('/') !== (url.length - 1)) {
        url += "/";
      }
      url += this.getPaths().join(OctaneUrl.PATH_SEPARATOR);
    }

    let hasParam = false;
    for (let key in this.queryParams) {
      if (this.queryParams.hasOwnProperty(key)) {
        hasParam = true;
        break;
      }
    }

    //Append query params
    url = hasParam ? url + "?" + this.createQueryString() : url;

    return url;
  }
}
