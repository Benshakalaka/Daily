import {IOctaneHttpClient} from "./IOctaneHttpClient";
import {IHttpService, IPromise} from "angular";
import IAuthentication from "../authentication/IAuthentication";
import {OctaneHttpResponse} from "./OctaneHttpResponse";
import {GetOctaneHttpRequest, OctaneHttpRequest, OctaneRequestMethod, PostOctaneHttpRequest} from "./OctaneHttpRequest";

interface IHashMap {
  [key: string]: string
}

export default class OctaneHttpClient implements IOctaneHttpClient {
  //Constants
  private OAUTH_AUTH_URL = "/authentication/sign_in";
  private OAUTH_SIGNOUT_URL = "/authentication/sign_out";
  private LWSSO_COOKIE_KEY = "LWSSO_COOKIE_KEY";
  private OCTANE_USER_COOKIE_KEY = "OCTANE_USER";

  private requestToEtagMap: IHashMap = {};
  private lastUsedAuthentication: IAuthentication;

  constructor(private $http: IHttpService, private domainUrl: string) {

  }

  authenticate(authentication: IAuthentication): IPromise<boolean> {
    this.lastUsedAuthentication = authentication;
    let request = new PostOctaneHttpRequest(
      this.domainUrl + this.OAUTH_AUTH_URL,
      OctaneHttpRequest.JSON_CONTENT_TYPE,
      authentication.getAuthenticationJsonObj()
    );
    request.setAcceptType(OctaneHttpRequest.JSON_CONTENT_TYPE);
    return this.execute(request).then(response => {
        return response.isSuccessStatusCode();
      }
    ).catch(reason => {
      this.lastUsedAuthentication = null;
      throw reason;
    });
  }

  signOut() {
    this.lastUsedAuthentication = null;
  }

  execute(octaneHttpRequest: OctaneHttpRequest): IPromise<OctaneHttpResponse> {
    const param = this.createHttpRequestParam(octaneHttpRequest);
    return this.$http(param).then(response => {
        return new OctaneHttpResponse(response.status, response);
      }
    );
  }

  private createHttpRequestParam(octaneHttpRequest: OctaneHttpRequest): any {
    let param = {url: octaneHttpRequest.getRequestUrl()};
    let headers = new HttpHeaders();
    if (this.lastUsedAuthentication) {
      headers.restClientType = this.lastUsedAuthentication.getClientHeader();
    }
    switch (octaneHttpRequest.getOctaneRequestMethod()) {
      case OctaneRequestMethod.GET:
        param['method'] = 'get';
        headers.accept = (<GetOctaneHttpRequest>octaneHttpRequest).getAcceptType();
        let hashKey = octaneHttpRequest.getKeyForMap();
        const eTagHeader = this.requestToEtagMap[hashKey];
        if (eTagHeader) {
          headers.ifNoneMatch = eTagHeader;
        }
        param['headers'] = headers.toJsonObj();
        break;
      case OctaneRequestMethod.POST:
        param['method'] = 'post';
        let postRequest = <PostOctaneHttpRequest>octaneHttpRequest;
        param['data'] = postRequest.getContent();
        headers.accept = postRequest.getAcceptType();
        headers.contentType = postRequest.getContentType();
        param['headers'] = headers.toJsonObj();
        break;
    }
    return param;
  }
}

class HttpHeaders {
  private static ACCEPT_HEADER_NAME = 'Accept';
  private static IF_NONE_MATCH_HEADER_NAME = 'If-None-Match';
  private static CONTENT_TYPE_HEADER_NAME = 'Content-Type';
  private static CLIENT_TYPE_HEADER = "HPECLIENTTYPE";

  accept: string;
  ifNoneMatch: string; // eTag for caching
  contentType: string;
  restClientType: string;

  toJsonObj(): any {
    let json = {};
    if (this.accept) {
      json[HttpHeaders.ACCEPT_HEADER_NAME] = this.accept;
    }
    if (this.ifNoneMatch) {
      json[HttpHeaders.IF_NONE_MATCH_HEADER_NAME] = this.ifNoneMatch;
    }
    if (this.contentType) {
      json[HttpHeaders.CONTENT_TYPE_HEADER_NAME] = this.contentType;
    }
    if (this.restClientType) {
      json[HttpHeaders.CLIENT_TYPE_HEADER] = this.restClientType;
    }
    return json;
  }
}
