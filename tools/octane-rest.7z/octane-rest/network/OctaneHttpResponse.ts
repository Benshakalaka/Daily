export class OctaneHttpResponse {

  public constructor(private statusCode: number, private httpResponse: any) {

  }

  /**
   * @return - Returns whether received a successful HTTP status code
   */
  public isSuccessStatusCode(): boolean {
    return this.statusCode >= 200 && this.statusCode < 300;
  }

  public getHttpResponse(): any {
    return this.httpResponse;
  }
}
