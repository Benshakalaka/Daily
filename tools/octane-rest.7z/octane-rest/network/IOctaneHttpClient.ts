import IAuthentication from "../authentication/IAuthentication";
import {OctaneHttpRequest} from "./OctaneHttpRequest";
import {OctaneHttpResponse} from "./OctaneHttpResponse";
import {IPromise} from "angular";

export interface IOctaneHttpClient {

  /**
   * Authenticate with the Octane server using an implementation of the {@link IAuthentication} class
   * @param authentication implementation of {@link IAuthentication}
   * @return true if the authentication was successful, false otherwise
   */
  authenticate(authentication: IAuthentication): IPromise<boolean>;

  /**
   * Signs out and removes cookies
   */
  signOut();

  execute(octaneHttpRequest: OctaneHttpRequest): IPromise<OctaneHttpResponse>;
}
