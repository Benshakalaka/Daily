export enum OctaneRequestMethod {
  GET,
  POST,
  PUT,
  DELETE,
  POST_BINARY
}

export abstract class OctaneHttpRequest {
  public static JSON_CONTENT_TYPE = "application/json; charset=UTF-8";
  public static OCTET_STREAM_CONTENT_TYPE = "application/octet-stream";

  private requestUrl: string;
  private octaneRequestMethod: OctaneRequestMethod;

  protected constructor(requestUrl: string, octaneRequestMethod: OctaneRequestMethod) {
    this.requestUrl = requestUrl;
    this.octaneRequestMethod = octaneRequestMethod;
  }

  public getRequestUrl(): string {
    return this.requestUrl;
  }

  public getOctaneRequestMethod(): OctaneRequestMethod {
    return this.octaneRequestMethod;
  }

  public getKeyForMap(): string {
    return this.octaneRequestMethod + this.requestUrl;
  }
}

class DeleteOctaneHttpRequest extends OctaneHttpRequest {
  constructor(url: string) {
    super(url, OctaneRequestMethod.DELETE);
  }
}

class HasAcceptOctaneHttpRequest extends OctaneHttpRequest {
  private acceptType: string;

  protected constructor(url: string, octaneRequestMethod: OctaneRequestMethod) {
    super(url, octaneRequestMethod);
  }

  public setAcceptType(acceptType: string): HasAcceptOctaneHttpRequest {
    this.acceptType = acceptType;

    //noinspection unchecked
    return this;
  }

  public getAcceptType(): string {
    return this.acceptType;
  }
}

export class GetOctaneHttpRequest extends HasAcceptOctaneHttpRequest {
  public constructor(url: string) {
    super(url, OctaneRequestMethod.GET);
  }
}

abstract class HasContentOctaneHttpRequest extends HasAcceptOctaneHttpRequest {
  private contentType: string;
  private content: string;

  protected constructor(url: string, octaneRequestMethod: OctaneRequestMethod, contentType: string, content: string) {
    super(url, octaneRequestMethod);

    this.contentType = contentType;
    this.content = content;
  }

  public getContentType(): string {
    return this.contentType;
  }

  public getContent() {
    return this.content;
  }
}

export class PutOctaneHttpRequest extends HasContentOctaneHttpRequest {
  public constructor(url: string,
                     contentType: string,
                     content: string) {
    super(url, OctaneRequestMethod.PUT,
      contentType,
      content
    );
  }
}

export class PostOctaneHttpRequest extends HasContentOctaneHttpRequest {
  public constructor(url: string,
                     contentType: string,
                     content: string) {
    super(url, OctaneRequestMethod.POST,
      contentType,
      content
    );
  }
}

export class PostBinaryOctaneHttpRequest extends HasContentOctaneHttpRequest {

  private binaryInputStream: any;
  private binaryContentName: string;
  private binaryContentType: string;

  public constructor(url: string, binaryInputStream: any,
                     content: string, binaryContentName: string, binaryContentType: string) {
    super(url, OctaneRequestMethod.POST_BINARY, OctaneHttpRequest.OCTET_STREAM_CONTENT_TYPE, content);
    this.binaryInputStream = binaryInputStream;
    this.binaryContentName = binaryContentName;
    this.binaryContentType = binaryContentType;
  }

  public getBinaryInputStream(): any {
    return this.binaryInputStream;
  }

  public getBinaryContentName(): string {
    return this.binaryContentName;
  }

  public getBinaryContentType(): string {
    return this.binaryContentType;
  }
}
