/**
 * An abstract representation of a request
 */
import {OctaneUrl} from "./OctaneUrl";
import OctaneHttpClient from "./OctaneHttpClient";
import {OctaneHttpRequest} from "./OctaneHttpRequest";
import {IPromise} from "angular";
import {EntityModel} from "../model/EntityModel";
import {OctaneCollection} from "../entities/OctaneCollection";
import {ModelParser} from "../model/ModelParser";

export class OctaneRequest {
  private octaneUrl: OctaneUrl;

  public constructor(protected octaneHttpClient: OctaneHttpClient, urlDomain: string, entityId?: string) {
    this.octaneUrl = new OctaneUrl(urlDomain);
    this.octaneHttpClient = octaneHttpClient;
    if (entityId) {
      this.octaneUrl.addPaths(entityId);
    }
  }

  public getOctaneUrl(): OctaneUrl {
    return this.octaneUrl;
  }

  public getFinalRequestUrl(): string {
    return this.octaneUrl.toString();
  }

  /**
   * get entities result based on Http Request
   *
   * @param octaneHttpRequest - http request
   * @return entities ased on Http Request
   */
  public getEntitiesResponse(octaneHttpRequest: OctaneHttpRequest): IPromise<OctaneCollection<EntityModel>> {
    return this.octaneHttpClient.execute(octaneHttpRequest).then(octaneHttpResponse => {
      let response = octaneHttpResponse.getHttpResponse();
      let entityModels: OctaneCollection<EntityModel> = ModelParser.getInstance().getEntities(response.data);
      return entityModels;
    });

    // let data:OctaneHttpResponse = response.getHttpResponse().data.data;
    //
    // if (response.isSuccessStatusCode() && json != null && !json.isEmpty()) {
    //   newEntityModels = ModelParser.getInstance().getEntities(json);
    //
    // }
    //
    // return newEntityModels;
  }

  /**
   * get entity result based on Http Request
   *
   * @param octaneHttpRequest the request object
   * @return EntityModel
   */
  public getEntityResponse(octaneHttpRequest: OctaneHttpRequest): IPromise<EntityModel> {

    return this.octaneHttpClient.execute(octaneHttpRequest)
      .then(octaneHttpResponse => {
        let newEntityModel: EntityModel = null;
        return newEntityModel;
      });

    // String json = response.getContent();
    // logger.debug(String.format(LOGGER_RESPONSE_JSON_FORMAT, json));
    // if (response.isSuccessStatusCode() && (json != null && !json.isEmpty())) {
    //
    //   JSONTokener tokener = new JSONTokener(json);
    //   JSONObject jsonObj = new JSONObject(tokener);
    //   newEntityModel = ModelParser.getInstance().getEntityModel(jsonObj);
    // }
    //
    // return newEntityModel;

  }

}
