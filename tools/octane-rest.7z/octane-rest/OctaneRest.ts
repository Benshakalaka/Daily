import OctaneHttpClient from "./network/OctaneHttpClient";
import {IPromise} from "angular";
import IAuthentication from "./authentication/IAuthentication";
import SimpleUserAuthentication from "./authentication/SimpleUserAuthentication";
import {GetOctaneHttpRequest} from "./network/OctaneHttpRequest";
import {EntityList} from "./entities/EntityList";

export default class OctaneRest {
  private static SITE_ADMIN_DOMAIN_FORMAT = "/api/siteadmin/";
  private static SHARED_SPACES_DOMAIN = "/api/shared_spaces/";
  private static WORKSPACES_DOMAIN = "workspaces/";
  private static SHARED_SPACES_PATH = "/api/shared_spaces";
  private static WORKSPACES_PATH_FORMAT = "/api/shared_spaces/${spaceId}/workspaces";
  private static HPSSO_COOKIE_CSRF_HEADER_NAME = 'HPSSO_COOKIE_CSRF';
  private static CLIENT_TYPE = 'HPE_MQM_UI';

  private octaneHttpClient: OctaneHttpClient;
  private ssoCookieCsrfHeader: string;
  public sharedSpaceId: string;
  public workspaceId: string;

  constructor(private $http, private domain: string) {
    this.octaneHttpClient = new OctaneHttpClient($http, domain);
  }

  public authenticate(userName: string, password: string): IPromise<boolean> {
    let auth: IAuthentication = new SimpleUserAuthentication(userName, password, OctaneRest.CLIENT_TYPE);
    return this.octaneHttpClient.authenticate(auth);
  }

  public signOut() {
    return this.octaneHttpClient.signOut();
  }

  public getSpaces(): IPromise<any> {
    let request = new GetOctaneHttpRequest(this.domain + OctaneRest.SHARED_SPACES_PATH);
    return this.octaneHttpClient.execute(request)
      .then(octaneResponse => {
        let response = octaneResponse.getHttpResponse();
        if (!response.data.total_count) {
          return null;
        }
        let spaces = response.data.data;
        return spaces;
      });
  }

  public getWorkspaces(spaceId: string): IPromise<any> {
    let workspacesPath = this.domain + "/api/shared_spaces/" + spaceId + "/workspaces";
    let request = new GetOctaneHttpRequest(workspacesPath);
    return this.octaneHttpClient.execute(request).then(octaneResponse => {
      let response = octaneResponse.getHttpResponse();
      let workspaces = response.data.data;
      return workspaces;
    });
  }

  /**
   * <p>
   * Creates a new EntityList context.  The entity name should be the collection name of the entity.
   * For example {@code defects, tests, releases}
   * </p>
   * This method creates a new separate entity context each time that can be reused or used in parallel
   * <p>
   *
   * @param entityName - The name of the entity as a collection
   * @return A new EntityList object that list of entities
   */
  public entityList(entityName: string): EntityList {
    return new EntityList(this.octaneHttpClient, this.getBaseDomainFormat() + entityName)
  }

  /**
   * get the base domain based on workspaceId and idsharedSpaceId
   *
   * @return base domain
   */
  protected getBaseDomainFormat(): string {
    let baseDomain = this.domain + OctaneRest.SITE_ADMIN_DOMAIN_FORMAT;
    if (this.sharedSpaceId) {
      baseDomain = this.domain + OctaneRest.SHARED_SPACES_DOMAIN + this.sharedSpaceId + '/';
      if (this.workspaceId)
        baseDomain = baseDomain + OctaneRest.WORKSPACES_DOMAIN + this.workspaceId + '/';
    }

    return baseDomain;
  }
}
