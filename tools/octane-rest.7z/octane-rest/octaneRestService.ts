import {IAngularStatic, IPromise} from "angular";
import OctaneRest from "./OctaneRest";
import {Query, QueryBuilder} from "./query/Query";
import {QueryMethod} from "./query/QueryMethod";
import {ModelParser} from "./model/ModelParser";

declare var angular: IAngularStatic;

class OctaneRestService {
  private restClient: OctaneRest;

  constructor(private $http) {

  }

  authenticate(urlDomain: string, userName: string, password: string): IPromise<boolean> {
    this.restClient = new OctaneRest(this.$http, urlDomain);
    return this.restClient.authenticate(userName, password);
  }

  getRestClient(): OctaneRest {
    return this.restClient;
  }

  createQueryBuilder(fieldName: string, method: QueryMethod, fieldValue) {
    return Query.statement(fieldName, method, fieldValue);
  }

  createQueryBuilder2(queryString: string) {
    return new QueryBuilder(queryString);
  }

  getModelParser(): ModelParser {
    return ModelParser.getInstance();
  }
}

angular.module('platform')
  .service('octaneRestService', ['$http', OctaneRestService]);

