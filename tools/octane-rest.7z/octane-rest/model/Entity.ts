/**
 * An interface representing the basic Octane entity.
 */
export interface Entity {

  /**
   * Returns the type of the entity.  All entities that are returned from the server have a type.
   * If a type has not been set this will return null
   * @return the type of the entity or null if not set
   */
  getType(): string;

  /**
   * Returns the ID of the entity.  Most (if not all) entities have an ID.  However it is possible for the entity to not
   * have an ID even when returned from the server.
   * If the ID has not been set this will return null
   * @return the ID of the entity or null if not set
   */
  getId(): string;
}
