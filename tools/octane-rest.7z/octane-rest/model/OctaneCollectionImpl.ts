/**
 * Implementation of the {@link OctaneCollection}.  Implements a {@link java.util.Set}
 */
import {Entity} from "./Entity";
import {OctaneCollection} from "../entities/OctaneCollection";

export class OctaneCollectionImpl<T extends Entity> implements OctaneCollection<T> {

  private entities: Array<T> = new Array<T>();
  private totalCount: number; // -1 means no total count set
  private _exceedsTotalCount: boolean;

  constructor(totalCount: number, exceedsTotalCount: boolean) {
    this._exceedsTotalCount = exceedsTotalCount;
    this.totalCount = totalCount;
  }

  public getCollection(): Array<T> {
    return this.entities;
  }

  public getTotalCount(): number {
    return this.totalCount;
  }

  public exceedsTotalCount(): boolean {
    return this._exceedsTotalCount;
  }
}
