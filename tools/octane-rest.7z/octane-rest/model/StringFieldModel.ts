/**
 *
 * This class hold the StringFieldModel objects and serve as a string type FieldModel data holder
 *
 *
 */
import {FieldModel} from "./FieldModel";

export class StringFieldModel implements FieldModel {

  //Private
  private name = "";
  private value = "";

  /**
   * Creates a new StringFieldModel object
   *
   * @param newName - Field name
   * @param newValue - Field Value
   */
  public constructor(newName: string, newValue: string) {

    this.setValue(newName, newValue);
  }

  /**
   * get value
   */
  public getValue(): string {
    return this.value;
  }

  /**
   * get name
   */
  public getName(): string {
    return this.name;
  }

  /**
   * set value - name/value
   */
  public setValue(newName: string, newValue: string) {

    this.name = newName;
    this.value = newValue;
  }
}
