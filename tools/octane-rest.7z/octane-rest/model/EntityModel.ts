/**
 * This class hold the EntityModel objects and server as an entity data holder
 * entities.
 * The EntityModel class has two states - clean and dirty.  When creating a new entity from scratch then each addition
 * will be considered dirty and will be sent to the server when creating or updating.
 * When the entity has been returned from the server then the initial state will be considered clean.  Each change after
 * that (for example by using a method set*) will make the entity "dirty" and will be sent to the server when used for updates
 * Note - the id field is <em>always</em> considered a dirty field since it needs to be added
 */
import {Entity} from "./Entity";
import {FieldModel} from "./FieldModel";
import {StringFieldModel} from "./StringFieldModel";

export class EntityModel implements Entity {

  /**
   * ID field, should always be sent to the server (always dirty)
   */
  public static ID_FIELD_NAME = "id";

  /**
   * Field that keeps track if the entity has changed on the server vs what is being sent from the client
   * If it's contained in the entity model, it should always be sent back to the server (always dirty)
   * This prevents users to overwrite other people's changes from their client side cached entity
   */
  public static CLIENT_LOCK_STAMP_FIELD_NAME = "client_lock_stamp";


  /**
   * The internal map of data that this entity represents
   */
  private _data: DirtyHashMap;

  /**
   * Creates a new EntityModel object with given field models
   * Use this when create entity model with mass of fields.
   *
   * @param values      - a collection of field models
   * @param entityState The initial state of the entity when constructing.  Once these fields have been initialised
   *                    the entity is considered to be dirty
   */
  public constructor(values?: Array<FieldModel>, entityState?: EntityState) {
    if (!entityState) {
      entityState = EntityState.DIRTY;
    }
    this._data = new DirtyHashMap(entityState);
    if (values) {
      for (let field of values) {
        this._data.put(field.getName(), field);
      }
    }
    this._data.entityState = EntityState.DIRTY;
  }

  /**
   * Creates a new EntityModel object with solo string field
   * The entity will be considered dirty and thus these fields will be updated
   *
   * @param value - a collection of field models
   * @param key   The key to the model
   */
  public static createEntityModel(key: string, value: string): EntityModel {
    let entityModel = new EntityModel();
    let fldModel: FieldModel = new StringFieldModel(key, value);
    entityModel._data.put(key, fldModel);
    return entityModel;
  }

  /**
   * getter of entity value
   *
   * @return a collection of field models
   */
  public getValues(): Array<FieldModel> {
    // TODO: why hashset?
    // return new HashSet<>(this._data.values());
    return this._data.values();
  }

  /**
   * Returns all dirty values.
   * Used when sending the entity to be updated
   *
   * @return a collection of field models
   */
  getDirtyValues(): Array<FieldModel> {
    return this._data.dirtyValues();
  }

  /**
   * getter of single field
   *
   * @param key the fieldName
   * @return the field of specified field name
   */
  public getValue(key: string): FieldModel {
    return this._data[key];
  }

  /**
   * Remove a value from completely, different from setting the value to null
   *
   * @param key the fieldName
   */
  public removeValue(key: string) {
    this._data.remove(key);
  }

  /**
   * setter of new entity value, all old fields are cleared
   * @param values - a collection of field models
   * @return EntityModel with the field models set as a values
   */
// TODO: why values is Set in Java
  public setValues(values: Array<FieldModel>): EntityModel {
    if (values != null) {
      this._data.clear();
      for (let field of values) {
        this._data.put(field.getName(), field);
      }
    }
    return this;
  }

  /**
   * setter of single field, update if field exists
   * @param fieldModel the single field to update
   * @return EntityModel with the field model set as a value
   */
  public setValue(fieldModel: FieldModel): EntityModel {
    this._data.put(fieldModel.getName(), fieldModel);
    return this;
  }

  public getType(): string {
    const type = <StringFieldModel> this.getValue("type");
    return type ? type.getValue() : null;
  }

  public getId(): string {
    let id = <StringFieldModel>this.getValue("id");
    return id ? id.getValue() : null;
  }
}

/**
 * Represents the state of the entity.  In most cases it will be DIRTY.  However - when an entity is retrieved from the
 * server then the initial state will be CLEAN (all those fields will not be updated unless changed)
 */
export enum EntityState {
  CLEAN, DIRTY
}

/**
 * Internal Map that keeps the state of fields to be updated
 */
class DirtyHashMap {

  private fields: { [key: string]: FieldModel } = {};
  /**
   * The fields that should be updated
   */
  private dirtyFields: { [key: string]: boolean } = {};
  /**
   * The current state of the map
   */
  entityState: EntityState;

  /**
   * Initialise the hashmap with this initial state
   *
   * @param entityState The state to initialise the map
   */
  constructor(entityState: EntityState) {
    this.entityState = entityState;
  }

  public put(key: string, value: FieldModel): FieldModel {
    if (this.entityState === EntityState.DIRTY) {
      this.dirtyFields[key] = true;
    }
    this.fields[key] = value;
    return value;
  }


  public remove(key: string): FieldModel {
    if (this.entityState === EntityState.DIRTY) {
      this.dirtyFields[key] = true;
    }
    let value = this.fields[key];
    delete this.dirtyFields[key];
    return value;
  }

  public clear() {
    this.fields = {};
    this.dirtyFields = {};
  }

  public values(): Array<FieldModel> {
    let retFields = new Array<FieldModel>();
    for (let key in this.fields) {
      retFields.push(this.fields[key]);
    }
    return retFields;

  }

  /**
   * Returns all values that are dirty
   *
   * @return Dirty values
   */
  public dirtyValues(): Array<FieldModel> {
    let retFields = new Array<FieldModel>();
    for (let key in this.fields) {
      if (key === EntityModel.ID_FIELD_NAME ||
        key === EntityModel.CLIENT_LOCK_STAMP_FIELD_NAME ||
        this.dirtyFields[key]) {
        retFields.push(this.fields[key]);
      }
    }
    return retFields;
  }
}
