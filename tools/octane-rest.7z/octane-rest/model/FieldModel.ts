/**
 *
 * Interface of FieldModel
 *
 *
 */
export interface FieldModel {
  getValue(): any;

  setValue(name: string, value: any);

  getName(): string;
}
