import {FieldModel} from "./FieldModel";

export class FieldModelImpl implements FieldModel {
  constructor(protected name: string, protected value: any) {

  }

  getValue(): any {
    return this.value;
  }

  setValue(name: string, value: any) {
    this.name = name;
  }

  getName(): string {
    return this.name;
  }
}
