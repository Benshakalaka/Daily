import {EntityModel, EntityState} from "./EntityModel";
import {FieldModel} from "./FieldModel";
import {OctaneCollectionImpl} from "./OctaneCollectionImpl";
import {OctaneCollection} from "../entities/OctaneCollection";
import {FieldModelImpl} from "./FieldModelImpl";

declare var _;

export class ModelParser {
  private static JSON_DATA_NAME = "data";
  private static JSON_ERRORS_NAME = "errors";
  private static JSON_TOTAL_COUNT_NAME = "total_count";
  private static JSON_EXCEEDS_TOTAL_COUNT_NAME = "exceeds_total_count";
  private static REGEX_DATE_FORMAT = "\\d{4}-\\d{1,2}-\\d{1,2}T\\d{1,2}:\\d{1,2}:\\d{1,2}Z";
  private static LOGGER_INVALID_FIELD_SCHEME_FORMAT = " field scheme is invalid";

  private static modelParser: ModelParser = new ModelParser();

  private constructor() {
  }

  public static getInstance(): ModelParser {
    return this.modelParser;
  }

  /**
   * get a new json object based on a given EntityModel object
   *
   * @param entityModel the given entity model object
   * @param onlyDirty   Return only dirty fields (used for updates)
   * @return new json object based on a given EntityModel object
   */
  public getEntityJSONObject(entityModel: EntityModel, onlyDirty: boolean): any {

    let fieldModels: Array<FieldModel> = onlyDirty ? entityModel.getDirtyValues() : entityModel.getValues();
    let objField = {};
    for (let field of fieldModels) {
      objField[field.getName()] = this.getFieldValue(field);
    }

    return objField;
  }

  /**
   * get a new json object based on a given EntityModel list
   *
   * @param entitiesModels - Collection of entities models
   * @param onlyDirty      Converts only dirty fields (relevant for updating entity)
   * @return new json object conatin entities data
   */
  public getEntitiesJSONObject(entitiesModels: Array<EntityModel>, onlyDirty: boolean): any {
    let objBase = {};
    let objEntities: Array<any> = new Array<any>();
    objBase[ModelParser.JSON_DATA_NAME] = objEntities;
    objBase[ModelParser.JSON_TOTAL_COUNT_NAME] = entitiesModels.length;
    objBase[ModelParser.JSON_EXCEEDS_TOTAL_COUNT_NAME] = false;
    for(let model of entitiesModels) {
      objEntities.push(this.getEntityJSONObject(model, onlyDirty));
    }

    return objBase;
  }

  /**
   * GetEntities an object that represent a field value based on the Field Model
   *
   * @param fieldModel the source fieldModel
   * @return field value
   */
  private getFieldValue(fieldModel: FieldModel): any {
    let fieldValue;
    let tmpValue = fieldModel.getValue();

    if (tmpValue instanceof EntityModel) { // Check if it is reference field
      let fieldEntityModel = fieldModel.getValue();
      fieldValue = null;

      if (fieldEntityModel != null) {
        fieldValue = this.getEntityJSONObject(fieldEntityModel, false);
      }
    } else if (tmpValue instanceof OctaneCollectionImpl) {
      let entities = fieldModel.getValue();
      fieldValue = this.getEntitiesJSONObject(entities, false);
    } else {
      fieldValue = fieldModel.getValue();
    }
    return fieldValue;
  }

  /**
   * get a new EntityModel object based on json object
   *
   * @param jsonEntityObj - json object
   * @return new EntityModel object
   */
  public getEntityModel(jsonEntityObj: any): EntityModel {

    let fieldModels: Array<FieldModel> = new Array<FieldModel>();
    let entityModel: EntityModel;
    for (let key in jsonEntityObj) {
      let fldModel: FieldModel = null;
      let strKey = key;
      let aObj = jsonEntityObj[strKey];
      if (_.isObject(aObj)) {
        let fieldObject = aObj;

        if (fieldObject[ModelParser.JSON_DATA_NAME]) { // 'data' property means array type
          let entities = this.getEntities(fieldObject);
          fldModel = new FieldModelImpl(strKey, entities);
        } else if (fieldObject["type"] && fieldObject["id"]) {
          let ref = this.getEntityModel(fieldObject);
          fldModel = new FieldModelImpl(strKey, ref);
        } else {
          fldModel = new FieldModelImpl(strKey, fieldObject);
        }
      } else {
        fldModel = new FieldModelImpl(strKey, aObj);
      }

      fieldModels.push(fldModel);
    }

    entityModel = new EntityModel(fieldModels, EntityState.CLEAN);
    return entityModel;
  }

  /**
   * get a entity model collection based on a given json string
   *
   * @param json The JSON to parse
   * @return entity model collection based on a given json string
   */
  public getEntities(jsonObj: any): OctaneCollection<EntityModel> {
    let entityModels: OctaneCollection<EntityModel>;
    if (jsonObj[ModelParser.JSON_EXCEEDS_TOTAL_COUNT_NAME] !== undefined && jsonObj[ModelParser.JSON_TOTAL_COUNT_NAME] !== undefined) {
      let exceedsTotalAmount = jsonObj[ModelParser.JSON_EXCEEDS_TOTAL_COUNT_NAME];
      let totalCount = jsonObj[ModelParser.JSON_TOTAL_COUNT_NAME];
      entityModels = new OctaneCollectionImpl<EntityModel>(totalCount, exceedsTotalAmount);
    } else {
      entityModels = new OctaneCollectionImpl<EntityModel>(-1, false);
    }
    for(let jsonEntityObj of jsonObj.data) {
      let model = this.getEntityModel(jsonEntityObj);
      entityModels.getCollection().push(model)
    }

    return entityModels;
  }

// public boolean hasErrorModels(String json) {
//   JSONTokener tokener = new JSONTokener(json);
//   JSONObject jsonObj = new JSONObject(tokener);
//   return jsonObj.has(JSON_ERRORS_NAME) && jsonObj.get(JSON_ERRORS_NAME) instanceof JSONArray;
// }
//
// /**
//  * GetEntities Error models based on a given error json string
//  *
//  * @param json - json string with error information
//  * @return collection of error models
//  */
// public Collection<ErrorModel> getErrorModels(String json) {
//
//   JSONTokener tokener = new JSONTokener(json);
//   JSONObject jsonObj = new JSONObject(tokener);
//   JSONArray jsonErrArr = jsonObj.getJSONArray(JSON_ERRORS_NAME);
//   Collection<ErrorModel> ErrModels = new ArrayList<>();
//   IntStream.range(0, jsonErrArr.length()).forEach((i) -> ErrModels.add(getErrorModelFromjson(jsonErrArr.getJSONObject(i).toString())));
//
//   return ErrModels;
// }
//
// /**
//  * GetEntities Error model based on a given error json string
//  *
//  * @param json - json string with error information
//  * @return error model
//  */
// public ErrorModel getErrorModelFromjson(String json) {
//
//   JSONTokener tokener = new JSONTokener(json);
//   JSONObject jsonErrObj = new JSONObject(tokener);
//
//   Set<FieldModel> fieldModels = new HashSet<>();
//   Iterator<?> keys = jsonErrObj.keys();
//
//   while (keys.hasNext()) {
//
//     String strKey = (String) keys.next();
//     Object aObj = jsonErrObj.get(strKey);
//
//     FieldModel fldModel;
//
//     if (aObj == JSONObject.NULL) {
//       fldModel = new ReferenceErrorModel(strKey, null);
//     } else if (aObj instanceof JSONObject || aObj == JSONObject.NULL) {
//       EntityModel ref = getEntityModel(jsonErrObj.getJSONObject(strKey));
//       fldModel = new ReferenceFieldModel(strKey, ref);
//     } else {
//
//       fldModel = new StringFieldModel(strKey, aObj.toString());
//     }
//
//     fieldModels.add(fldModel);
//
//   }
//
//
//   return new ErrorModel(fieldModels);
// }
}
