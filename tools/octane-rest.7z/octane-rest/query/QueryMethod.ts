import {Query, QueryBuilder} from "./Query";

export enum QueryMethod {
  EqualTo = 0,
  LessThan,
  GreaterThan,
  GreaterThanOrEqualTo,
  LessThanOrEqualTo,
  In,
  Between
}

export class QueryMethodConverter {
  // constant
  private static DATE_TIME_ISO_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
  private static DATE_TIME_UTC_ZONE_NAME = "UTC";

  private static COMPARISON_OPERATOR_EQUALS = "EQ";
  private static COMPARISON_OPERATOR_LESS = "LT";
  private static COMPARISON_OPERATOR_GREATER = "GT";
  private static COMPARISON_OPERATOR_LESS_EQUALS = "LE";
  private static COMPARISON_OPERATOR_GREATER_EQUALS = "GE";
  static COMPARISON_OPERATOR_IN = "IN";
  static COMPARISON_OPERATOR_BETWEEN = "BTW";

  public static convert(method: QueryMethod, field: string, value: any): string {
    if(method === QueryMethod.EqualTo) {
      return QueryMethodConverter.equalTo(field, value);
    } else  if(method === QueryMethod.LessThan) {
      return QueryMethodConverter.lessThan(field, value);
    } else if(method === QueryMethod.GreaterThan) {
      return QueryMethodConverter.greaterThan(field, value);
    } else if(method === QueryMethod.LessThanOrEqualTo) {
      return QueryMethodConverter.lessThanOrEqualTo(field, value);
    } else if(method === QueryMethod.GreaterThanOrEqualTo) {
      return QueryMethodConverter.greaterThanOrEqualTo(field, value);
    } else if(method === QueryMethod.In) {
      return QueryMethodConverter.in(field, value);
    } else  if(method === QueryMethod.Between) {
      return QueryMethodConverter.between(field, value);
    }

    return null;
  }

  /**
   * Generates a query string for "equal to" comparison
   *
   * @param field - field name
   * @param value - value to compare the field with
   * @return query string
   */
  static equalTo(field: string, value): string {
    return "(" + field + " " + QueryMethodConverter.COMPARISON_OPERATOR_EQUALS + " " + QueryMethodConverter.toString(value) + ")";
  }

  /**
   * Generates a query string for "less than" comparison
   *
   * @param field - field name
   * @param value - value to compare the field with
   * @return query string
   */
  static lessThan(field: string, value): string {
    return "(" + field + " " + QueryMethodConverter.COMPARISON_OPERATOR_LESS + " " + QueryMethodConverter.toString(value) + ")";
  }

  /**
   * Generates a query string for "greater than" comparison
   *
   * @param field - field name
   * @param value - value to compare the field with
   * @return query string
   */
  static greaterThan(field: string, value): string {
    return "(" + field + " " + QueryMethodConverter.COMPARISON_OPERATOR_GREATER + " " + QueryMethodConverter.toString(value) + ")";
  }

  /**
   * Generates a query string for "less than or equal to" comparison
   *
   * @param field - field name
   * @param value - value to compare the field with
   * @return query string
   */
  static lessThanOrEqualTo(field: string, value): string {
    return "(" + field + " " + QueryMethodConverter.COMPARISON_OPERATOR_LESS_EQUALS + " " + QueryMethodConverter.toString(value) + ")";
  }

  /**
   * Generates a query string for "greater than or equal to" comparison
   *
   * @param field - field name
   * @param value - value to compare the field with
   * @return query string
   */
  static greaterThanOrEqualTo(field: string, value): string {
    return "(" + field + " " + QueryMethodConverter.COMPARISON_OPERATOR_GREATER_EQUALS + " " + QueryMethodConverter.toString(value) + ")";
  }

  /**
   * Generates a query string for "in"
   *
   * @param field - field name
   * @param value - values to add to the in
   * @return query string
   */
  static in(field: string, value: Array<any>): string {
    if (value == null) {
      return "";
    }
    let tmpArr = new Array<string>();
    for (let ele of value) {
      tmpArr.push(QueryMethodConverter.toString(ele));
    }
    return "(" + field + " " + QueryMethodConverter.COMPARISON_OPERATOR_IN + " "
      + tmpArr.join(',')
      + ")";
  }

  /**
   * Generates a query string for "btw"
   * Note: This method accepts an {@link Between} object but according to the REST API specification only Dates and Numbers
   * are allowed to be sent to the server for between
   *
   * @param field         - field name
   * @param lowerAndUpper - An object of type {@link Between}
   * @return query string
   */
  static between(field: string, lowerAndUpper: Between): string {
    if (lowerAndUpper == null) {
      return "";
    }
    return "(" + field + " " + QueryMethodConverter.COMPARISON_OPERATOR_BETWEEN + " "
      + QueryMethodConverter.toString(lowerAndUpper.lower) + "..." + QueryMethodConverter.toString(lowerAndUpper.upper)
      + ")";
  }

  /**
   * Generates a string representation of a given Object
   *
   * @param value - Object to convert
   * @return string representation
   */
  private static toString(value): string {
    if (typeof value === undefined || value === null) {
      return "{null}";
    } else if (value instanceof QueryBuilder) {
      return "{" + (<QueryBuilder>value).build().getQueryString() + "}";
    } else {
      return "'" + value.toString() + "'";
    }
  }
}

class Between {
  lower;
  upper;

  public constructor(lower, upper) {
    this.lower = lower;
    this.upper = upper;
  }
}
