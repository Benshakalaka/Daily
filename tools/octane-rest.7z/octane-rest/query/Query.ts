import {QueryMethod, QueryMethodConverter} from "./QueryMethod";

export class Query {

  protected queryString = "";

  /**
   * Negates the given query string
   * @param queryString - input query string
   * @return resulting string after negation
   */
  public static negate(queryString: string): string {
    return "!" + queryString;
  }

/**
 * QueryBuilder Statement
 * @param fieldName - field name
 * @param method - comparison function to use
 * @param fieldValue - value to compare with
 * @return The new object that can be used to build the query
 */
public static statement(fieldName:string, method:QueryMethod , fieldValue):QueryBuilder  {
  return new QueryBuilder(QueryMethodConverter.convert(method, fieldName, fieldValue));
}

/**
 * QueryBuilder not
 * @param fieldName - field name
 * @param method - comparison function to use
 * @param fieldValue - value to compare with
 * @return The new object that can be used to build the query
 */
public static not(fieldName:string, method:QueryMethod , fieldValue):QueryBuilder {
  return new QueryBuilder(Query.negate(QueryMethodConverter.convert(method, fieldName, fieldValue)));
}

/**
 * Constructor
 * @param builder - the query builder to use for building the query
 */
public constructor( builder:QueryBuilder) {
  this.queryString = builder.getQueryString();
}

/**
 * Accessor method of query string
 * @return query string
 */
public  getQueryString():string {
  return this.queryString;
}

/**
 * @return a string representation of the object.
 */
public toString():string {
  return this.queryString;
}
}

export class QueryBuilder {

  private queryString = "";

  public constructor(queryString: string) {
    this.queryString = queryString;
  }

  /**
   * Accessor method for the query builder string.
   * @return query builder's string
   */
  public getQueryString(): string {
    return this.queryString;
  }

  /**
   * Builds a query from the current builder
   * @return builded query
   */
  public build(): Query {
    return new Query(this);
  }

  /**
   * Generates a builder by applying the logical "and" operator between the current builder and the resulting operation of the input values after negation.
   * @param fieldName - field name
   * @param method - comparison function to use
   * @param fieldValue - value to compare with
   * @return resulting builder
   */
  public andNot2(fieldName: string, method: QueryMethod, fieldValue): QueryBuilder {
    this.queryString += ";" + Query.negate(QueryMethodConverter.convert(method, fieldName, fieldValue));
    return this;
  }

  /**
   * Generates a builder by applying the logical "and" operator between the current builder and the resulting operation of the input values.
   * @param fieldName - field name
   * @param method - comparison function to use
   * @param fieldValue - value to compare with
   * @return resulting builder
   */
  public and(fieldName: string, method: QueryMethod, fieldValue): QueryBuilder {
    let rightQueryString = QueryMethodConverter.convert(method, fieldName, fieldValue);
    this.queryString += ";" + rightQueryString;
    return this;
  }

  /**
   * Generates a builder by applying the logical "and" operator between the current builder and the input builder.
   * @param qb - query builder
   * @return resulting builder
   */
  public and2(qb: QueryBuilder): QueryBuilder {
    this.queryString += ";" + qb.getQueryString();
    return this;
  }

  /**
   * Generates a builder by applying the logical "and" operator between the current builder and the input builder after negation.
   * @param qb - query builder
   * @return resulting builder
   */
  public andNot(qb: QueryBuilder): QueryBuilder {
    this.queryString += ";" + Query.negate(qb.getQueryString());
    return this;
  }

  /**
   * Generates a builder by applying the logical "or" operator between the current builder and the resulting operation of the input values.
   * @param fieldName - field name
   * @param method - comparison function to use
   * @param fieldValue - value to compare with
   * @return resulting builder
   */
  public or2(fieldName: string, method: QueryMethod, fieldValue): QueryBuilder {
    let rightQueryString = QueryMethodConverter.convert(method, fieldName, fieldValue);
    this.queryString += "||" + rightQueryString;
    return this;
  }

  /**
   * Generates a builder by applying the logical "or" operator between the current builder and the resulting operation of the input values after negation.
   * @param fieldName - field name
   * @param method - comparison function to use
   * @param fieldValue - value to compare with
   * @return resulting builder
   */
  public orNot2(fieldName: string, method: QueryMethod, fieldValue): QueryBuilder {
    this.queryString += "||" + Query.negate(QueryMethodConverter.convert(method, fieldName, fieldValue));
    return this;
  }

  /**
   * Generates a builder by applying the logical "or" operator between the current builder and the input builder.
   * @param qb - query builder
   * @return resulting builder
   */
  public or(qb: QueryBuilder): QueryBuilder {
    this.queryString += "||" + qb.getQueryString();
    return this;
  }

  /**
   * Generates a builder by applying the logical "or" operator between the current builder and the input builder after negation.
   * @param qb - query builder
   * @return resulting builder
   */
  public orNot(qb): QueryBuilder {
    this.queryString += "||" + Query.negate(qb.getQueryString());
    return this;
  }

  /**
   * Wraps current builder content into a parenthesis
   * @return with parentheses
   */
  private parenthesis(): QueryBuilder {
    this.queryString = "(" + this.queryString + ")";
    return this;
  }

  /**
   * Wraps current builder content into a parenthesis
   * @param queryBuilder {@link QueryBuilder} to wrap into parenthesis
   * @return enclose the inner query of the QueryBuilder in parenthesis
   */
  public static parenthesis(queryBuilder: QueryBuilder): QueryBuilder {
    return queryBuilder.parenthesis();
  }
}
